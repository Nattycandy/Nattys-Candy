Natty's Candy - Static Website

Files included:
- index.html, shop.html, about.html, contact.html, faq.html
- css/style.css
- assets/*.svg (logo, banner, product placeholders)

How to use:
1. Unzip the package.
2. Open index.html in your browser to preview.
3. To host for free:
   - Option A: Create a GitHub repo and enable GitHub Pages (choose main branch / root).
   - Option B: Upload the files to Netlify or Vercel (drag & drop in dashboard).
4. If you prefer Google Sites: copy/paste text and images from these pages into Google Sites (site needs manual recreation).

Replace the mailto links with your PayPal/Stripe links:
- Create PayPal "Buy Now" buttons and replace the href of each Buy Now button.
- Or create Stripe payment links and paste them into the button hrefs.

Need help updating links, images, or hosting? Reply and I'll help.
